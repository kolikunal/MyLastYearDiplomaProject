start_geolocator()
{
clear
. kk.sh
. googlemaps.sh
}
