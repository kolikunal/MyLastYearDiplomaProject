search()
{
var=$1
firefox https://www.google.com/maps/place/$var
}

