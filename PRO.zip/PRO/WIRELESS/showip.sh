showIP(){

    echo " "
    echo -n -e "Your public IP adress is ->"
    GET http://www.vermiip.es/ | grep "Tu IP p&uacute;blica es" | cut -d ':' -f2 | cut -d '<' -f1
    echo " "
    echo -n -e "Your private IP adress is ->"
    hostname -I
    echo " "
    echo -e "press <Enter> to exit"
   echo "press 1 to return to menu"  
    read a
    if [ $a -eq 1 ]
    then
    wireless
    fi 
}
