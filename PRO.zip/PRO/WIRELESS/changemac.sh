changeMAC(){
    echo " "
      sleep 3
    echo -e "proceed to change your MAC address in the interface 'wlan0'..."
    echo " "
    sleep 2
    ifconfig wlan0 down
    echo " "
    macchanger -a wlan0
    echo " "
    ifconfig wlan0 up
    echo " "
    echo -e "Process Completed!, you can check your new MAC address"
    echo " "
    echo -e "Press <Enter> to exit"
    echo "press 1 to return to menu"
read a
    if [ $a -eq 1 ]
    then
    wireless
    fi
 }
