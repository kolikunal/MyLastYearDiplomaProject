wireless()
{
clear
export PS1="$(tput setaf 2)wlan0>$(tput setaf 6)"
echo "------------------------------------------------"
tiv -h 50 -w 50 w.jpg
echo "------------------------------------------------"
echo "------------------------------------------------"
tiv -h 50 -w 50 l.jpg
echo "------------------------------------------------"
sleep 1
echo "$(tput setaf 6)1.Repair Network"
echo "2.Show my IP address"
echo "3.show my mac address"
echo "4.change my mac address"
echo "5.mac attack"
echo "6.Scan available wifis"
echo "7.exit"
echo "$(tput setaf 9)---->Enter Your choice---->" && read a
case $a in
1) . repairnetwork.sh && repairNetwork;;
2) . showip.sh && showIP;;
3) . showmac.sh && showMAC;;
4) . changemac.sh && changeMAC;;
5) . macAttack.sh && macAttack;;
6) . wifiscanner.sh && iwScan;;
7) exit;;
*) echo "Wrong choice";;
esac
}
