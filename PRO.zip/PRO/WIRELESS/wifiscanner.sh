#!/bin/bash 
function iwScan() 
{
    set -o noglob
    local AP S
    while read -r AP; do
      [[ "${AP//'SSID: '*}" == '' ]] && printf '%b' "${AP/'SSID: '}\n"
     [[ "${AP//'signal: '*}" == '' ]] && ( S=( ${AP/'signal: '} ); printf '%b' "${S[0]},";)
   done
   set +o noglob
echo "press ctrl^c to exit"

}
iwScan <<< "$(iw wlan0 scan)"
