repairNetwork(){

    echo " "
    echo -e "Re-establishing the network scanner of your computer..."
    echo " "
    sleep 3
    service network-manager restart
    echo -e "Finished!"
    echo " "
    sleep 3
    echo "press 1 to return to menu"
    read a
    if [ $a -eq 1 ]
    then
    wireless
    fi

}
