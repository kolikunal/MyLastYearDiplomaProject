showMAC(){

    echo " "
    echo -e "Your new MAC address will be displayed..."
    echo " "
    sleep 2
    macchanger -s wlan0 | grep Current
    echo " "
    echo -e "Press <Enter> to exit"
    echo "press 1 to return to menu"
   read a
    if [ $a -eq 1 ]
    then
    wireless
    fi
}
