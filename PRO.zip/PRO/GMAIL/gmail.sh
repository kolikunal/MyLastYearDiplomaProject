export PS1="$(tput setaf 3)mail>>"
sendmail()
{
clear
echo ""
tiv -h 50 -w 50 r.png
echo ""
echo "$(tput setaf 6)"
./GmailSender.py
}
