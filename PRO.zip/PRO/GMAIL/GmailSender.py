#!/usr/bin/env python
import sys
import smtplib
import os
import getpass
try:
   input = raw_input
except:
   pass
from email.mime.text import MIMEText
try:
   open('log.txt')
except IOError as e:
  answer = input ("You have to LOGIN! Do you want to login (y/n) ?: ")
  if answer=="y":
	print ("\n|***LOGIN***|")
	username = input ("\n\nusername:")
	password = getpass.getpass('Password:')
	#password = input ("password:")
	logw = open ('log.txt', 'w')
	logw.write(username)
	logw.write("\n")
	logw.write(password)
	logw.close()	
  else:
	exit()
logr = open ('log.txt', 'r')
username = logr.readline()
password = logr.readline()
print ("")
print ("Welcome", username)
print ("\n|Main-Menu|\n")
print ("[1] Send G-MAil\n")
print ("[2] Exit\n")
print ("[3] LOGOUT & Exit\n")
answer = input ("Type [number] to select option: ")
if answer=="2":
	exit()
elif answer=="3":
	os.remove('log.txt')
	exit()
elif answer=="1":
	msg = MIMEText(input ("\n|MAIN TEXT|\n"))
	msg['Subject'] = input('Subject: ')
	msg['From'] = username
	msg['To'] = input('To: ')
	s = smtplib.SMTP('smtp.gmail.com', 587)
	s.ehlo()
	s.starttls()
	s.login(msg['From'], password) 
	try:
   		s.send_message(msg)
	except AttributeError:
   		s.sendmail(msg['From'], [msg['To']], msg.as_string())
	s.quit()
else:
	print("ERROR !!! INVALID NUMBER")
	exit()
